# cascade-router (Max for Live)

The routing half of abletools as an M4L device: cascading **input and output**
routing across armed tracks, with mono/stereo pair-awareness and the modern
Live 11+ routing-object API.

## Building the device

`cascade-router.js` is the logic; wrap it in a device:

1. In Ableton, create a new **Max Audio Effect** (or MIDI Effect) and click Edit.
2. Add a `js cascade-router.js` object.
3. Add UI: a number box → `inputStart $1`, another → `outputStart $1`, toggles →
   `inputs $1` / `outputs $1`, a message `step tight` / `step pair`, and two
   buttons sending `scan` and `apply` into the `js`. Wire the `js` outlet to a
   `message` or `comment` for status.
4. Freeze and save as `cascade-router.amxd`.

Or reuse the existing `max-patches/cascade-router/cascade-router.maxpat` and
point its `js` object at this updated file.

## Usage

1. Drop the device on any track.
2. **Arm** the tracks you want to route.
3. Set start channels, toggle inputs/outputs, choose step policy.
4. **Scan** to preview, then **Apply**.

### Step policy

- **tight** (Pro Tools default): mono advances by 1, stereo by 2 → `1, 2, 3` /
  `1-2, 3-4`.
- **pair** (SSL/analog-desk workflow): every track consumes a stereo pair slot,
  so mono tracks land on odd channels (`1, 3, 5, 7`) leaving the even channel
  free for stereo-linking on the console.

## Note on parity with the CLI

The allocation logic mirrors `packages/routing-core` exactly, but is re-expressed
in Max's ES5-style `js` dialect because a Max `js` object cannot import npm
modules. If you change the algorithm, change it in both places (the routing-core
unit tests are the source of truth).
