// cascade-router.js  (abletools) — v2
// Pro Tools-style cascading INPUT + OUTPUT routing for Ableton Live.
//
// Improvements over the original cascade-router:
//   1. Cascades inputs AND outputs (the original did outputs only).
//   2. Uses the modern Live 11+ routing-OBJECT API: it sets input/output
//      routing TYPE to "Ext. In"/"Ext. Out" (picked from the available_* list),
//      then selects the channel OBJECT whose display_name matches the target —
//      instead of the fragile integer form the original used, which is why it
//      warned "manual adjustment may be needed".
//   3. Honors a step policy: "tight" (Pro Tools default: mono +1, stereo +2)
//      or "pair" (SSL workflow: mono on odd channels, even left free).
//
// This is the Max-for-Live front-end of abletools. The identical allocation
// logic ships as a pure-TS core (packages/routing-core) behind the CLI; kept in
// sync by hand because M4L's js object cannot import npm modules.
//
// Inlets (see the .amxd): messages below. Outlet 0 = status text.

autowatch = 1;
inlets = 1;
outlets = 1;

var startInput = 1;      // first hardware input channel
var startOutput = 1;     // first hardware output channel
var doInputs = 0;        // route inputs?  (0/1)
var doOutputs = 1;       // route outputs? (0/1)
var stepPolicy = "tight"; // "tight" | "pair"
var plan = [];           // computed on scan, applied on apply

function post_(s) { post(s + "\n"); }

// ---- message handlers (wired from UI in the patch) ----------------------
function inputStart(v)  { startInput  = Math.max(1, v | 0); }
function outputStart(v) { startOutput = Math.max(1, v | 0); }
function inputs(v)      { doInputs  = v ? 1 : 0; }
function outputs(v)     { doOutputs = v ? 1 : 0; }
function step(sym)      { stepPolicy = (sym === "pair") ? "pair" : "tight"; }
function scan()         { scanTracks(); }
function apply()        { applyRouting(); }
function bang()         { scanTracks(); }

// ---- helpers ------------------------------------------------------------

// Channel step: "tight" advances by width, "pair" always by 2.
function channelStep(width) { return stepPolicy === "pair" ? 2 : width; }

// Detect stereo by inspecting the track's current output channel label
// (Live labels stereo pairs "1/2"; mono is a bare number). Falls back to mono.
function trackWidth(track) {
  try {
    var label = track.get("output_routing_channel");
    var s = label ? label.toString() : "";
    return (s.indexOf("/") !== -1) ? 2 : 1;
  } catch (e) { return 1; }
}

// From a track's available_*_routing_types, pick the "Ext. In"/"Ext. Out" one
// and set it, so the hardware channel list becomes available. dir = "input"|"output".
function setExternalType(track, dir) {
  var listProp = "available_" + dir + "_routing_types";
  var typeProp = dir + "_routing_type";
  var types = track.get(listProp);
  if (!types) return false;
  // ableton API returns a flat "id name id name ..." or list of dicts depending
  // on version; we iterate the object list form.
  for (var i = 0; i < types.length; i++) {
    var t = types[i];
    var name = (t && t.display_name) ? t.display_name : ("" + t);
    if (/ext/i.test(name)) { track.set(typeProp, t); return true; }
  }
  return false;
}

// Choose the channel object whose label matches channel `ch` (width-aware).
function pickChannel(track, dir, ch, width) {
  var chans = track.get("available_" + dir + "_routing_channels");
  if (!chans) return null;
  var wanted = (width >= 2) ? (ch + "/" + (ch + 1)) : ("" + ch);
  for (var i = 0; i < chans.length; i++) {
    var c = chans[i];
    var name = (c && c.display_name) ? c.display_name : ("" + c);
    if (name.replace(/\s+/g, "") === wanted) return c;
  }
  // positional fallback: the ch-th channel (1-based)
  return chans[ch - 1] || null;
}

// ---- scan: build the plan from armed tracks -----------------------------
function scanTracks() {
  plan = [];
  var out = "abletools cascade plan\n\n";
  var tracksApi = new LiveAPI("live_set tracks");
  var n = tracksApi.getcount("children") || tracksApi.get("length");
  var inCur = startInput, outCur = startOutput;

  for (var i = 0; i < n; i++) {
    var track = new LiveAPI("live_set tracks " + i);
    if (!track.get("arm")) continue;                 // only armed tracks
    if (track.get("has_midi_input") == 1 && track.get("has_audio_output") == 0) continue; // skip pure MIDI

    var name = track.get("name");
    var width = trackWidth(track);
    var entry = { index: i, name: name, width: width, inCh: null, outCh: null };

    if (doInputs) { entry.inCh = inCur; inCur += channelStep(width); }
    if (doOutputs) { entry.outCh = outCur; outCur += channelStep(width); }
    plan.push(entry);

    out += name + (width === 2 ? " (stereo)" : " (mono)");
    if (entry.inCh !== null)  out += "  in " + entry.inCh + (width === 2 ? "/" + (entry.inCh + 1) : "");
    if (entry.outCh !== null) out += "  out " + entry.outCh + (width === 2 ? "/" + (entry.outCh + 1) : "");
    out += "\n";
  }

  if (plan.length === 0) out += "No armed tracks. Arm the tracks you want to route.";
  outlet(0, out);
  post_("scan: " + plan.length + " track(s)");
}

// ---- apply: write the routing objects -----------------------------------
function applyRouting() {
  if (plan.length === 0) { outlet(0, "Nothing to apply. Click Scan first."); return; }
  var ok = 0;
  for (var i = 0; i < plan.length; i++) {
    var p = plan[i];
    var track = new LiveAPI("live_set tracks " + p.index);
    try {
      if (p.inCh !== null && setExternalType(track, "input")) {
        var inC = pickChannel(track, "input", p.inCh, p.width);
        if (inC) track.set("input_routing_channel", inC);
      }
      if (p.outCh !== null && setExternalType(track, "output")) {
        var outC = pickChannel(track, "output", p.outCh, p.width);
        if (outC) track.set("output_routing_channel", outC);
      }
      ok++;
    } catch (e) {
      post_("error on " + p.name + ": " + e);
    }
  }
  outlet(0, "Applied routing to " + ok + " of " + plan.length + " track(s).");
  post_("apply complete");
}

post_("abletools cascade-router v2 loaded");
