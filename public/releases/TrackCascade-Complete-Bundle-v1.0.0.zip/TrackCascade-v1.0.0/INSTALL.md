# abletools

**Ableton Live productivity workflow enhancements — Pro Tools-inspired.**

Ableton Live is brilliant for ideas and weak for the fast, repetitive session
plumbing that Pro Tools makes instant: spinning up a batch of tracks, cascading
their hardware I/O, keyboard-driving the layout. `abletools` closes that gap —
a growing suite of workflow tools that make Live feel as fast to set up as a
tracking date in Pro Tools.

Today it ships two, and they compose:

- **New Tracks dialog** — batch-create N tracks by type · count · name · arm, in
  one undo step. The "New Track" dialog Live never had.
- **Cascading I/O** — fan a selection across ascending inputs/outputs with correct
  mono/stereo pair allocation.

```
Track 1 (stereo) → out 1/2
Track 2 (mono)   → out 3
Track 3 (mono)   → out 4
Track 4 (stereo) → out 5/6
```

See the [roadmap](docs/roadmap.md) for what's next (R/T zoom, batch rename,
color cascade).

## Free source · paid build

abletools is **open source (MIT)** — clone it, read it, build it yourself for
free. If you'd rather not install a toolchain, the **ready-to-use build** is for
sale: a signed, double-click **`.ablx`** extension + pre-built **`.amxd`** device,
preset packs, install guide, updates, and support.

| | Free (this repo) | Paid build (Gumroad) |
| --- | --- | --- |
| Full source | ✅ | ✅ (same code) |
| Build it yourself | ✅ | — |
| Signed/notarized `.ablx` installer | build it | ✅ ready to double-click |
| Pre-built `.amxd` device | build it | ✅ |
| Preset packs, install guide | — | ✅ |
| Updates + support | community | ✅ |

You're not paying for the code — it's right here. You're paying for the packaged,
signed, it-just-works build and support. See [docs/packaging.md](docs/packaging.md).

## Why two surfaces?

Ableton exposes different powers to different extension APIs, so abletools meets
each job on the surface that can actually do it — sharing one pure-TypeScript
brain (`routing-core`) between them.

| Capability | Surface | Status |
| --- | --- | --- |
| **New Tracks dialog** — create by type · count · name · arm | **Extensions SDK** (Live 12.4.5+ Suite, beta) | ✅ right-click → modal webview |
| **Cascading input/output routing** | **cascade-router** device (Max for Live) / **CLI** (ableton-js) | ✅ Live 11+, any edition |

> **Routing is not in the Extensions SDK yet** (verified against the beta's
> `index.d.mts`: `Track` exposes `name`, `arm`, `mute`, `solo`, `mixer`,
> `devices` — no routing symbols). So the SDK owns creation; the Live Object
> Model path owns routing. When the SDK gains routing, only the extension's
> `lom-adapter` implementation changes. Full detail: [docs/feasibility-matrix.md](docs/feasibility-matrix.md).

## Packages

```
packages/routing-core   Pure-TS brain: cascade allocation, auto-naming, presets. Zero Ableton deps. 25 unit tests.
packages/lom-adapter    Adapter interfaces (TrackCreator / TrackRouter) + plan executor + channel matcher.
extension/              Extensions SDK extension — the New Tracks dialog. Builds against the beta SDK.
cli/                    Node/Bun CLI over ableton-js — full create + cascade on stable Live 11/12.
m4l/                    Improved cascade-router Max for Live device (inputs + outputs, routing-object API).
docs/                   Feasibility matrix, packaging model, roadmap.
```

## Quick start

### CLI (works today, stable Live 11/12)

Requires the [`ableton-js`](https://github.com/leolabs/ableton-js) control
surface installed and selected in Live's MIDI preferences.

```bash
bun install
cd cli
bun run src/index.ts --count 8 --name Mic --inputs --arm   # dry-run: prints the plan
bun run src/index.ts --preset drum-bus-pairs --apply       # run against Live
bun run src/index.ts --list-presets
```

The CLI **defaults to dry-run**; pass `--apply` to create + route in Live.

### Extensions SDK (New Tracks dialog, Live 12.4.5+ Suite beta)

```bash
./scripts/setup-sdk.sh /path/to/extensions-sdk   # copy the SDK tarballs in
cd extension && npm install
npm run start                                     # build + load into a running Live
```

Then right-click any track → **abletools: New Tracks…**  (or just buy the build.)

### Max for Live routing device

See [`m4l/README.md`](m4l/README.md) to wrap `cascade-router.js` in an `.amxd`.

## Development

```bash
bun install
bun test           # routing-core + lom-adapter unit tests
bun run typecheck  # workspace tsc -b
```

## Prior art & how abletools differs

First to **unify** batch creation and cascade routing, with mono/stereo
pair-aware allocation none of the existing tools do. Track Creator creates but
never routes; the ElisabethHomeland cascade device routes existing tracks only
and needs each pre-set to "Ext. Out" by hand; ClyphX Pro is closed/paid with no
create-N-with-cascade; AbletonOSC / ableton-js expose the raw LOM but ship no
convenience command.

## License & trademark

MIT © 2026 Nakul Tiruviluamala. Not affiliated with or endorsed by Ableton AG.
"Ableton" and "Live" are trademarks of Ableton AG. The Ableton Extensions SDK is
Ableton's, used under its SDK license and **not redistributed here** — you supply
it via `scripts/setup-sdk.sh`.
